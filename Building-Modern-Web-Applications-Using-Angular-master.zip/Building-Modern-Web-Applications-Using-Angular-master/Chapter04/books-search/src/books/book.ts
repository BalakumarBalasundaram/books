export class Book {
  id: number;
  isbn: number;
  title: string;
  authors: string;
  published: string;
  description: string;
  coverImage: string;
}