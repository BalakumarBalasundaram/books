import { Component } from '@angular/core';

@Component({
  selector: 'about-page',
  template: '<h2>This is About Page</h2>',
})
export class AboutComponent {
}
