# Instructions

Run the following commands to view the output of the example.

- `npm install`
- `npm run json-server`
- `npm start`
-  Navigate to `http://localhost:4200/`
