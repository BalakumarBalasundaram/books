import { Component } from '@angular/core';

@Component({
  selector: 'forms-app',
  template: '<registration-reactive-form></registration-reactive-form>'
})
export class AppComponent {
}