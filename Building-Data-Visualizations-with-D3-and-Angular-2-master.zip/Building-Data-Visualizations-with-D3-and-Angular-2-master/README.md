# Building-Data-Visualizations-with-D3-and-Angular-2
Building Data Visualizations with D3 and Angular 2, by Packt Publishing
