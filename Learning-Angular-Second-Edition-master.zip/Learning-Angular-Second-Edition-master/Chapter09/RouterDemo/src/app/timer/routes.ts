import { TimerComponent } from "./timer.component";

export const routes = [{
  path: 'timer',
  component: TimerComponent
}];

