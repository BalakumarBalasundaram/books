import { Component, OnInit } from '@angular/core';

@Component({
  template: `
  should show how many people ordered this product
  `
})
export class ProductsDetailOrders implements OnInit {
  constructor() { }

  ngOnInit() { }
}
