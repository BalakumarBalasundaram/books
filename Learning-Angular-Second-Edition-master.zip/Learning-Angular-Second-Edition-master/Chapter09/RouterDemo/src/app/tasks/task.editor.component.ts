import { Component } from '@angular/core';

@Component({
  selector: 'tasks-editor',
  templateUrl: 'task.editor.component.html'
})
export class TaskEditorComponent {
  constructor() { }
}
