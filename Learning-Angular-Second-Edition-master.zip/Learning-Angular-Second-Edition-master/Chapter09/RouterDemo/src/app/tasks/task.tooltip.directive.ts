import { Directive } from '@angular/core';

@Directive({ selector: '[task-tooltip]' })
export class TaskTooltipDirective {
  constructor() { }
}
