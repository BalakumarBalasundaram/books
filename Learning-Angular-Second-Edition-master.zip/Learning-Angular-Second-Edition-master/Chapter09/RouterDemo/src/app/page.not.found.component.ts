import { Component, OnInit } from '@angular/core';

@Component({
  template: `
  <h1>Page not found</h1>
  `
})

export class PageNotFoundComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
