import { Component, OnInit } from '@angular/core';

@Component({
  template: `
  lazy component
  `
})

export class LazyComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
