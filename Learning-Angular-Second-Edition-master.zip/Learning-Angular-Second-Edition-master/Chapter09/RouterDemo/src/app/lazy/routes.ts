import { LazyComponent } from "./lazy.component";

export const routes = [{
  path: 'lazy',
  component: LazyComponent
}];

