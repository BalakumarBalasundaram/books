import { Component, OnInit } from '@angular/core';

@Component({
  template: `
  jedi component
  `
})

export class JediComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
