import { Component } from '@angular/core';

@Component({
  template: `
  jedi header
  `
})

export class JediHeaderComponent {
  constructor() { }
}
