export interface Jedi {
  name: string;
  side: string;
}
