import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <jedi-list></jedi-list>
  `
})
export class AppComponent {
  title = 'app';
}
