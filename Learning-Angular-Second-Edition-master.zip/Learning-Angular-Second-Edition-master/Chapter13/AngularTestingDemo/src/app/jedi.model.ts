export class Jedi {
  constructor(public id, public name, public side) { }
}
