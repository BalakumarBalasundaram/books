import { Component } from '@angular/core';

@Component({
  selector: 'music-library',
  template: `
  <music-player></music-player>
  `
})
export class MusicLibraryComponent {
  constructor() { }
}
