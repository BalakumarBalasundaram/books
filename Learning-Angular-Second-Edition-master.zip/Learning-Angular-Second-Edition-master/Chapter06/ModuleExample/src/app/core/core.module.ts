import { SettingsService } from "./settings.service";
import { NgModule } from "@angular/core";

@NgModule({
  providers: [SettingsService]
})
export class CoreModule {

}
