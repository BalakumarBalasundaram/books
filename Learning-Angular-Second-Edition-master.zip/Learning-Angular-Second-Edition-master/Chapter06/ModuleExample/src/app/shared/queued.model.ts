export interface Queueable {
  queued: boolean;
}
