import { Component } from '@angular/core';

@Component({
  selector: 'task-detail',
  template: `task detail`
})

export class TaskDetailComponent{
  constructor() { }
}
